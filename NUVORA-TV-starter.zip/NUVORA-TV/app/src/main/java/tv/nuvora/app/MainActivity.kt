package tv.nuvora.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.widget.*
import android.graphics.Color
import android.text.InputType
import android.content.Context
import android.content.SharedPreferences
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.net.URLEncoder
import java.util.concurrent.Executors

data class LiveChannel(
    val name: String = "Canal",
    val stream_id: Int = 0,
    val stream_icon: String? = null,
    val epg_channel_id: String? = null,
    val direct_source: String? = null
)

class MainActivity : Activity() {
    private val http = OkHttpClient()
    private val gson = Gson()
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var channels: List<LiveChannel> = emptyList()
    private var server = ""
    private var username = ""
    private var password = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        prefs = getSharedPreferences("nuvora", Context.MODE_PRIVATE)
        showLogin()
    }

    private fun baseLayout(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 24)
            setBackgroundColor(Color.rgb(8, 13, 22))
        }
        setContentView(root)
        return root
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 26f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, 8, 0, 18)
    }

    private fun field(hintText: String, value: String = "", secret: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            textSize = 18f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.rgb(29, 41, 59))
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

    private fun action(text: String, run: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 17f
        setOnClickListener { run() }
    }

    private fun showLogin(message: String? = null) {
        val box = baseLayout()
        box.gravity = Gravity.CENTER
        box.addView(title("NUVORA TV"))
        val subtitle = TextView(this).apply {
            text = "Conecta tu servicio de TV autorizado"
            textSize = 16f
            setTextColor(Color.LTGRAY)
        }
        box.addView(subtitle)
        val url = field("URL del servidor (ej. https://servidor:8080)", prefs.getString("server", "") ?: "")
        val user = field("Usuario", prefs.getString("username", "") ?: "")
        val pass = field("Contraseña", prefs.getString("password", "") ?: "", true)
        listOf(url, user, pass).forEach {
            box.addView(it, LinearLayout.LayoutParams(-1, 62).apply { topMargin = 10 })
        }
        if (message != null) box.addView(TextView(this).apply {
            text = message; setTextColor(Color.YELLOW); textSize = 14f
        })
        box.addView(action("CONECTAR") {
            server = url.text.toString().trim().trimEnd('/')
            username = user.text.toString().trim()
            password = pass.text.toString()
            if (server.isBlank() || username.isBlank() || password.isBlank()) {
                showLogin("Completa los tres campos.")
            } else {
                prefs.edit().putString("server", server).putString("username", username)
                    .putString("password", password).apply()
                loadChannels()
            }
        })
    }

    private fun encoded(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun loadChannels() {
        runOnUiThread {
            baseLayout().apply {
                gravity = Gravity.CENTER
                addView(title("NUVORA TV"))
                addView(TextView(this@MainActivity).apply {
                    text = "Conectando y cargando canales…"
                    setTextColor(Color.WHITE); textSize = 18f
                })
            }
        }
        worker.execute {
            try {
                val api = "$server/player_api.php?username=${encoded(username)}&password=${encoded(password)}&action=get_live_streams"
                val request = Request.Builder().url(api).build()
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw Exception("El servidor respondió ${response.code}")
                    val body = response.body?.string() ?: throw Exception("Respuesta vacía")
                    val type = object : TypeToken<List<LiveChannel>>() {}.type
                    channels = gson.fromJson(body, type) ?: emptyList()
                    if (channels.isEmpty()) throw Exception("No se encontraron canales en la cuenta.")
                    runOnUiThread { showChannels() }
                }
            } catch (e: Exception) {
                runOnUiThread { showLogin("No se pudo conectar: ${e.message ?: "error de red"}") }
            }
        }
    }

    private fun showChannels() {
        val box = baseLayout()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(title("NUVORA TV  •  TODOS LOS CANALES"), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(action("Cambiar cuenta") { showLogin() })
        box.addView(header)
        val search = field("Buscar canal…")
        box.addView(search, LinearLayout.LayoutParams(-1, 58))
        val list = ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(Color.DKGRAY)
            dividerHeight = 1
            isFocusable = true
        }
        box.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refresh(query: String) {
            val filtered = channels.filter { it.name.contains(query, true) }
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
                filtered.mapIndexed { index, ch -> "${index + 1}.  ${ch.name}" })
            list.setOnItemClickListener { _, _, position, _ ->
                play(filtered[position])
            }
        }
        refresh("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        list.requestFocus()
    }

    private fun play(channel: LiveChannel) {
        val streamUrl = channel.direct_source?.takeIf { it.isNotBlank() }
            ?: "$server/live/${encoded(username)}/${encoded(password)}/${channel.stream_id}.ts"
        val box = baseLayout()
        box.setPadding(0, 0, 0, 0)
        val view = PlayerView(this).apply {
            useController = true
            player = ExoPlayer.Builder(this@MainActivity).build().also {
                this.player = it
                it.setMediaItem(MediaItem.fromUri(streamUrl))
                it.prepare()
                it.playWhenReady = true
            }
        }
        playerView = view
        box.addView(view, LinearLayout.LayoutParams(-1, -1))
    }

    override fun onBackPressed() {
        if (player != null) {
            player?.release()
            player = null
            playerView = null
            showChannels()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        player?.release()
        worker.shutdown()
        super.onDestroy()
    }
}
