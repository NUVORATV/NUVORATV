# NUVORA TV — Android starter project

Reproductor IPTV básico para Android TV / Fire TV, para reproducir únicamente señales a las que el usuario tenga autorización de acceso.

## Incluye
- Inicio de sesión Xtream Codes (URL, usuario y contraseña).
- Consulta de `get_live_streams`.
- Una lista plana de canales, sin categorías.
- Búsqueda por nombre.
- Reproducción mediante AndroidX Media3 ExoPlayer.
- Preferencias locales para recordar la conexión.
- Workflow de GitHub Actions para compilar un APK de depuración.

## Compilar
Requiere JDK 17 y Android SDK 35:
```bash
gradle :app:assembleDebug
```
El APK se genera en:
`app/build/outputs/apk/debug/app-debug.apk`

También se puede ejecutar el workflow **Build NUVORA TV APK** desde la pestaña Actions de GitHub. El APK queda disponible como artifact de la ejecución.

## Limitaciones de este prototipo
- Es un punto de partida técnico, no una versión comercial terminada ni probada en Fire TV.
- El formato de URL de streams varía entre proveedores; algunos usan `.m3u8`, `.ts` u otras rutas. Puede requerir adaptación para el proveedor autorizado.
- El campo `direct_source` no siempre viene en la respuesta Xtream.
- No incluye aún logotipos en la lista, EPG, favoritos, cambio de canal con teclas, ni gestión remota de licencias.
- Las credenciales se guardan en preferencias locales para facilitar pruebas; antes de distribuir públicamente hay que migrarlas a almacenamiento cifrado (Android Keystore / EncryptedSharedPreferences) y añadir controles de privacidad.
- No contiene canales ni suscripciones. El usuario debe aportar un servicio y contenido que esté autorizado a utilizar.
- No hay pagos activos. La arquitectura de licencias se deberá añadir y probar antes de monetizar.

## Uso responsable
NUVORA TV es un reproductor. No incluye, distribuye ni proporciona acceso a canales, listas, claves o suscripciones de terceros.
